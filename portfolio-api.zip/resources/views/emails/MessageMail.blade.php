<x-mail::message>
# New Message Comes From

Name : {{$maildata['name']}} <br>
Email : {{$maildata['email']}} <br>
Message : {{$maildata['message']}}



Thanks,<br>

</x-mail::message>
